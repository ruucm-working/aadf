<template>
  <div id="result" :class="`${questionerType} ${questionerType}_${level}`">
    <div class="backgroundBottom"></div>
    <div class="resultContainer">
      <div class="resultTitle"><div class="resultTitleIcon"></div> 나의 문화다양성 지수는?</div>
      <div class="resultContent">
        <div class="resultContentText">
          <div class="resultContentTextIcon">“</div>
          <div class="resultContentTextDetail">{{detailText.detail}}</div>
        </div>
        <div class="resultContentSymbol">
          <div class="symbolImage" :class="`symbol_${level}`">
            {{questionerType === 'normal' ? totalScore : ''}}
          </div>
          <!-- <div class="symbolText" v-if="questionerType === 'children'">{{scripts.children[level].title}}</div> -->
        </div>
      </div>
      <div class="buttonContainer">
        <nuxt-link class="gotoQuestion" to="/test">문항해설보기</nuxt-link>
        <nuxt-link class="gotoAction" to="/action">실천과제보기</nuxt-link>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  data () {
    return {
      scripts: {
        normal: [
          {
            title: '상', // 100 ~ 90
            detail: '당신은 다른 문화에 대한 이해력, 타인과 공감하는 능력이 뛰어난 세계시민입니다. 주변 사람들과도 문화다양성과 인권에 관한 이야기를 나누면서 당신의 공감능력을 전파해보면 어떨까요?'
          },
          {
            title: '중', // 89 ~ 80
            detail: '코끼리를 삼킨 보아뱀을 알아보는 어린왕자처럼 당신은 이미 다름과 다양성을 존중할 수 있는 마음을 품고 계시군요. 우리 주변의 이주민과 소수자 문제에 좀 더 관심을 기울여 본다면 행동하는 세계시민으로 한 걸음 나아갈 수 있습니다.'
          },
          {
            title: '하', // 79 ~ 0
            detail: '나에게 친숙한 장소와 문화 속에서 행복하게 사는 것도 좋지만, 변화하는 세계에서 사람들의 다양한 모습에 관심을 가져보면 어떨까요? 다양성과 인권을 이해하는 사람은 흥미롭고 유쾌한 모습으로 더 많은 사람들과 소통하는 세계시민이 될 수 있을 것입니다.'
          }
        ],
        children: [
          {
            title: '봄날의 민들레', // 100 ~ 90
            detail: '당신은 다양한 문화를 이해하며 나와 다른 사람들과 공감할 수 있는 마음을 지닌 멋진 세계시민입니다. 봄날의 민들레 홀씨처럼 주변의 친구들과도 마음을 나눈다면, 당신으로 인해 세상은 좀 더 아름다고 멋진 곳이 될 것입니다.'
          },
          {
            title: '튼튼한 떡잎', // 89 ~ 80
            detail: '당신 안에는 이미 타인을 이해하고 다양한 문화를 소중히 여기는 마음이 자리 잡고 있습니다. 나와 조금 다른 주변 친구들의 어려움, 세계 곳곳의 인권 문제에 좀 더 관심을 기울이고 주변사람들과 이들에 대한 이야기를 함께 나눠보세요. 세계 시민의 역량을 갖춘 훌륭한 나무로 훌쩍 성장하게 될 것입니다.'
          },
          {
            title: '안개꽃 꽃다발', // 79 ~ 0
            detail: '함께 있기에 더욱 아름다운 하얀 안개꽃 꽃다발처럼 우리는 같은 모습, 같은 문화에서 편안함을 느낍니다. 그런데 변화하는 세계에 좀 더 관심을 가져보고 나와는 조금 다른 다양한 사람들에게도 마음을 열 수 있다면, 당신은 오색빛깔 꽃들을 가슴에 품은 멋진 세계시민으로 성장할 것입니다.'
          }
        ]
      }
    }
  },
  computed: {
    questionerType () {
      return this.$store.state.appConfig.questionerType
    },
    answerList () {
      return this.$store.state.answer.answerList
    },
    detailText () {
      // return seletetedScript
      return this.scripts[this.questionerType][this.level]
    },
    totalScore () {
      let score = 0
      for (const i in this.answerList) {
        if (this.answerList.hasOwnProperty(i)) {
          const answer = this.answerList[i];
          score += answer.answerPoint
        }
      }
      return score
    },
    level () {
      const score = this.totalScore
      if (score <= 100 && score >= 90) {
        return 0
      } else if (score <= 89 && score >= 80) {
        return 1
      } else if (score <= 79 && score >= 0) {
        return 2
      } else {
        return 2
      }
    }
  },
  mounted () {
    const answers = this.answerList
    if (
      (this.questionerType === 'normal' && answers.length === 15) ||
      (this.questionerType === 'children' && answers.length === 10) 
      ) {

    } else {
      alert("문제를 다 푸신 후 이 페이지에 접근하셔야합니다. 처음으로 돌아갑니다.")
      location.href = './'
      // this.$router.push('/')
    }
  },
  beforeRouteEnter (to, from, next) {
    if(from.name === null) {
      next('/')
    } else {
      next()
    }
  }
}
</script>

<style lang="scss">
$maxDeviceWidth: "767px";

#ollybollyApp {
  padding-bottom: 166px;
  margin: 0 auto;

  .backgroundBottom {
    z-index: 0;
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 166px;
    background-position: center;
  }
  .resultContainer {
    margin: 0 auto;
    width: 960px;
    @media screen and (max-device-width: $maxDeviceWidth) {
      width: 100vw;
    }
    .resultTitle {
      font-size: 24px;
      font-weight: 500;
      line-height: 2.33;
      text-align: left;
      color: #112254;
      .resultTitleIcon {
        display: inline-block;
        width: 25px;
        height: 39px;
      }
    }
    .resultContent {
      width: 960px;
      height: 473px;
      border-radius: 18px;
      background-color: #fafcfc;
      box-shadow: 0px 4px 0 0 rgba(183, 215, 241, 0.3);
      border: solid 1px #c8ddf7;
      @media screen and (max-device-width: $maxDeviceWidth) {
        position: relative;
        width: 99vw;
        height: 900px;
      }
      .resultContentText {
        display: inline-block;
        vertical-align: top;
        width: 55%;
        padding: 90px 5%;
        @media screen and (max-device-width: $maxDeviceWidth) {
          position: absolute;
          display: block;
          width: 90%;
          top: 300px;
          left: 0px;
          padding: 20px 5%;
        }
        .resultContentTextIcon {
          font-family: NanumMyeongjo;
          font-size: 80px;
          font-weight: bold;
          line-height: 0;
          text-align: left;
          padding-top: 30px;
        }
        .resultContentTextDetail {
          font-family: "Noto Sans KR";
          font-size: 24px;
          font-weight: 500;
          line-height: 1.71;
          text-align: left;
          color: #3d454c;
        }
      }
      .resultContentSymbol {
        display: inline-block;
        vertical-align: top;
        width: 25%;
        padding: 80px 20px;
        font-family: Bungee;
        font-size: 85.3px;
        text-align: center;
        color: #ffffff;
        @media screen and (max-device-width: $maxDeviceWidth) {
          position: absolute;
          display: block;
          width: 90%;
          top: 0px;
          left: 0px;
          padding: 40px 5% 0;
          text-align: center;
        }
        .symbolImage {
          width: 240px;
          height: 330px;
          line-height: 300px;
          margin-bottom: 40px;
          background-repeat: no-repeat;
          @media screen and (max-device-width: $maxDeviceWidth) {
            display: inline-block;
          }
        }
        .symbolText {

        }
      }
    }
    .buttonContainer {
      margin: 50px 0 0 0;
      text-align: center;
      .gotoQuestion,
      .gotoAction {
        display: inline-block;
        width: 150px;
        height: 40px;
        border-radius: 6px;
        font-size: 21px;
        line-height: 45px;
        text-align: center;
        color: #ffffff;
        text-decoration: none;
      }
      .gotoQuestion{
        margin-right: 20px;
      }
      .gotoAction {}
    }
  }
  &.normal {
    background-image: url('/img/ui/normalBackground1.jpg');
    .backgroundBottom {
      background-image: url('/img/ui/normalBackground2.png');
    }
    .resultTitle {
      .resultTitleIcon {
        background-color: #3360FC; // #199047
      }
    }
    .resultContent {
      box-shadow: 0px 4px 0 0 rgba(183, 215, 241, 0.3); // rgba(210, 176, 35, 0.3);
      border: solid 1px #c8ddf7; // #e8c533;
      .resultContentText {
        .resultContentTextIcon {
          color: #d8eaff; // #f5e18f;
        }
      }
      .resultContentSymbol {
        .symbolImage {
          background-image: url('/img/ui/normalReward.png');
          &::after {  
            content: "점";
            font-size: 25px;
            margin-left: -20px;
            line-height: 125px;
          }
        }
      }
    }
    .buttonContainer {
      .gotoQuestion {
        background-color: #2542b6; // #127139
      }
      .gotoAction {
        background-color: #386cfb; // #3ed37c
      }
    }
  }
  &.children {
    background-image: url('/img/ui/childrenBackground1.png');
    .backgroundBottom {
      background-image: url('/img/ui/childrenBackground2.png');
    }
    .resultTitle {
      .resultTitleIcon {
        background-color: #199047;
      }
    }
    .resultContent {
      box-shadow: 0px 4px 0 0 rgba(210, 176, 35, 0.3);
      border: solid 1px #e8c533;
      .resultContentText {
        @media screen and (max-device-width: $maxDeviceWidth) {
          top: 400px;
        }
        .resultContentTextIcon {
          color: #f5e18f;
        }
      }
      .resultContentSymbol {
        .symbolImage {
          background-repeat: no-repeat;
          &.symbol_0 {
            background-image: url('/img/ui/childrenReward0.png')
          }
          &.symbol_1 {
            background-image: url('/img/ui/childrenReward1.png')
          }
          &.symbol_2 {
            background-image: url('/img/ui/childrenReward2.png')
          }

        }
        .symbolText {
          font-family: NanumSquareRoundEB;
          font-size: 40px;
          line-height: 0.9;
          text-align: center;
          color: #212529;
        }
      }
    }
    .buttonContainer {
      .gotoQuestion {
        background-color: #127139;
      }
      .gotoAction {
        background-color: #3ed37c;
      }
    }
  }
}
</style>
