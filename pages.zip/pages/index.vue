<template>
  <section class="container">
    <div class="backgroundBottom"></div>
    <div class="introContainer">
      <img class="titleImage" src="/img/ui/introTitle.png" alt="나의 문화 다양성 점수는 몇 점?">
      <div class="titleText">문화다양성 감수성 테스트</div>
      <div class="introDesctiption">
        <div class="descriptionText strong">나는 문화다양성에 대해 얼마나 이해하고 실천하고 있을까요?</div>
        <div class="descriptionText">지금 문화다양성 감수성 셀프 테스트 통해 알아보세요.</div>
        <div class="descriptionText">문제를 푼 뒤 해설과 실천방법을 통해 내 안의 문화다양성을 한단계 더 높일 수 있어요.</div>
      </div>
      <div class="buttonContainer">
        <nuxt-link @click.native="setConfigQuestionTypeChildren" class="toChildren" :to="isTeacher ? '/?type=teacher' : '/test'"></nuxt-link>
        <nuxt-link @click.native="setConfigQuestionTypeNormal" class="toNormal" to="/test"></nuxt-link>
      </div>
      
      <div class="footerText">
        문화다양성 감수성 테스트는<br />
        <span style="color: #91979e;font-weight: 700;">구글닷오알지</span> 후원으로 연구/제작 되었습니다
        </div>
    </div>
  </section>
</template>

<script>

export default {
  methods: {
    setConfigQuestionTypeNormal () {
      this.$store.commit('answer/resetAll')
      this.$store.commit('setQuestionTypeNormal')
    },
    setConfigQuestionTypeChildren (e) {
      if (this.isTeacher) {
        alert('선생님은 어른용으로 접속해 주세요.')
        return false
      }
      this.$store.commit('answer/resetAll')
      this.$store.commit('setQuestionTypeChildren')
    }
  },
  computed: {
    isTeacher () {
      return this.$store.state.appConfig.isTeacher
    }
  },
  mounted () {
    if (location.search === '?type=teacher') {
      this.$store.commit('setTeacherMode')
    } else {
      this.$store.commit('unsetTeacherMode')
    }
    this.$store.commit('answer/resetAll')
  }
}
</script>

<style lang="scss">
$maxDeviceWidth: "767px";

.backgroundBottom {
  position: absolute;
  z-index: 0;
  bottom: 0;
  width: 100%;
  height: 263px;
  background-image: url('/img/ui/introBackgroundUnder.png');
  background-position: center;
  background-repeat: no-repeat;
}
.container {
  position: relative;
  background-color: #FCFAF7;
  margin: 0 auto;
  width: 100vw;
  padding-bottom: 0px;
}
.introContainer {
  position: relative;
  overflow: hidden;
  width: 600px;
  margin: 0 auto;
  padding-top: 50px;
  text-align: center;
  @media screen and (max-device-width: $maxDeviceWidth) {
    width: 100vw;
    padding-bottom: 90px;
  }
  .titleImage {
    margin-bottom: 8px;
  }
  .titleText {
    font-family: NanumSquareRoundEB;
    font-size: 57px;
    line-height: 1.5;
    color: #4a65fb;
    margin-bottom: 15px;
    @media screen and (max-device-width: $maxDeviceWidth) {
      word-break: keep-all;
      font-size: 45px;
      padding: 0 15px;
    }
  }
  .introDesctiption {
    .descriptionText {
      font-family: "Noto Sans KR";
      font-size: 15px;
      line-height: 1.73;
      color: #5a626b;
      &.strong {
        font-weight: 700;
      }
      @media screen and (max-device-width: $maxDeviceWidth) {
        margin: 0 10px;
        word-break: keep-all;
        &.strong {
          margin: 0;
        }
      }
    }
  }
  .buttonContainer {
    position: relative;
    width: 100%;
    height: 100px;
    margin-bottom: 5px;
    a {
      text-decoration: none;
    }
    a.toChildren {
      position: absolute;
      top: 20px;
      left: 125px;
      width: 172px;
      height: 55px;
      background-image: url('/img/ui/introGotoTestChildren.png');
      background-repeat: no-repeat;
      @media screen and (max-device-width: $maxDeviceWidth) {
        display: inline-block;
        position: relative;
        vertical-align: top;
        margin-right: 3%;
        left: unset;
        right: unset;
        background-size: 130px;
        width: 130px;
        height: 41px;
      }
      &::after {
        content: "(초등학생)";
        line-height: 135px;
        font-family: "Noto Sans KR";
        font-size: 14px;
        font-weight: 700;
        color: #adb5bd;
        margin-left: -40px;
        @media screen and (max-device-width: $maxDeviceWidth) {
          line-height: 105px;
        }
      }
    }
    a.toNormal {
      position: absolute;
      top: 20px;
      left: 315px;
      width: 155px;
      height: 55px;
      background-image: url('/img/ui/introGotoTestNormal.png');
      background-repeat: no-repeat;
      @media screen and (max-device-width: $maxDeviceWidth) {
        display: inline-block;
        position: relative;
        vertical-align: top;
        left: unset;
        right: unset;
        background-size: 118px;
        width: 118px;
        height: 41px;
      }
      &::after {
        content: "(중학생~성인)";
        line-height: 135px;
        font-family: "Noto Sans KR";
        font-size: 14px;
        font-weight: 700;
        color: #adb5bd;
        margin-left: -5px;
        @media screen and (max-device-width: $maxDeviceWidth) {
          line-height: 105px;
        }
      }
    }
    .buttonDescription {
      position: absolute;
      top: 75px;
      left: 340px;
      font-family: "Noto Sans KR";
      font-size: 14px;
      font-weight: 700;
      line-height: 2.14;
      color: #adb5bd;
      @media screen and (max-device-width: $maxDeviceWidth) {
        left: 215px;
      }
    }
  }
  .footerText {
    font-family: "Noto Sans KR";
    font-size: 13px;
    font-weight: 700;
    line-height: 1.5;
    color: #adb5bd;
    img {
      height: 14px;
    }
  }
}
</style>
