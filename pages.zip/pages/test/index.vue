<template>
  <section class="test" :class="appConfig.questionerType">
    <div class="backgroundBottom"></div>
    <questionFormat :class="appConfig.questionerType"></questionFormat>
  </section>
</template>

<script>
import questionFormat from '~/components/questionFormat/index.vue'

export default {
  components: {
    'questionFormat': questionFormat
  },
  computed: {
    appConfig () {
      return this.$store.state.appConfig
    },
    getGender () {
      // console.log('getGender',this.$store.state.answer.askData.gender)
      return this.$store.state.answer.askData.gender
    },
    getAge () {
      // console.log('getAge',this.$store.state.answer.askData.age)
      return this.$store.state.answer.askData.age
    },
  },
  beforeRouteEnter (to, from, next) {
    if(from.name === null) {
      next('/')
    } else {
      next()
    }
  },
  beforeRouteLeave (to, from, next) {
    if (this.getGender === '' || this.getAge === '' ) {
      // Do nothing
      alert('모든 항목에 응답해주셔아 합니다.')
    } else {
      next()
    }
  }
}
</script>

<style lang="scss">
.test {
  .backgroundBottom {
    position: absolute;
    z-index: 0;
    bottom: 0;
    width: 100%;
    height: 166px;
    background-position: center;
  }
  &.normal {
    background-image: url('/img/ui/normalBackground1.jpg');
    .backgroundBottom {
      background-image: url('/img/ui/normalBackground2.png');
    }
  }
  &.children {
    background-image: url('/img/ui/childrenBackground1.png');
    .backgroundBottom {
      background-image: url('/img/ui/childrenBackground2.png');
    }
  }
}
</style>
