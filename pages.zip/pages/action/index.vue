<template>
  <div id="action" :class="questionerType">
    <div class="backgroundBottom"></div>
    <actionView :type="questionerType" />
  </div>
</template>

<script>
import actionView from '~/components/actionFormat/'

export default {
  components: {
    'actionView': actionView
  },
  computed: {
    questionerType () {
      return this.$store.state.appConfig.questionerType
    },
    answerList () {
      return this.$store.state.answer.answerList
    }
  },
  mounted () {
    const answers = this.answerList
    if (
      (this.questionerType === 'normal' && answers.length === 15) ||
      (this.questionerType === 'children' && answers.length === 10) 
      ) {

    } else {
      // alert("문제를 다 푸신 후 이 페이지에 접근하셔야합니다. 처음으로 돌아갑니다.")
      // location.href = './'
      // this.$router.push('/')
    }
  },
  beforeRouteEnter (to, from, next) {
    if(from.name === null) {
      next('/')
    } else {
      next()
    }
  }
}
</script>

<style lang="scss">

#action {
  padding-bottom: 166px;
  .backgroundBottom {
    z-index: 0;
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 166px;
    background-position: center;
  }
  &.normal {
    background-image: url('/img/ui/normalBackground1.jpg');
    .backgroundBottom {
      background-image: url('/img/ui/normalBackground2.png');
    }
  }
  &.children {
    background-image: url('/img/ui/childrenBackground1.png');
    .backgroundBottom {
      background-image: url('/img/ui/childrenBackground2.png');
    }
  }
}
</style>
