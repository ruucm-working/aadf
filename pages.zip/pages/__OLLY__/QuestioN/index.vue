<template>
  <div id="admin">
    <div id="questionAdminLogin" v-if="!loginSuccess">
      <input type="text" v-model="ID" placeholder="ID">
      <input type="password" v-model="PW" placeholder="PASSWORD">
      <button @click="loginProcess">로그인</button>
    </div>
    <div id="questionContentsController" v-else>
      <div class="buttonContainer">
        <button @click="saveChangedQuestion">저장</button>
        <button @click="downloadCSV">CSV 파일 다운로드</button>
      </div>
      <div class="question normal">
        <div>어른용 질문 </div> 
        <div class="questionContainer" v-for="(entry, index) in changedQuestions.normal" :key="'normal_' + index">
          <div class="questionTitle">
            <span>{{entry.NUMBER}}</span>
            <input type="text" v-model="entry.TITLE" class="titleText">
          </div>
          <div class="questionEntryContainer">
            <ul>
              <li class="questionEntry" v-for="(elem, idx) in entry.CHOICE_ENTRY" :key="'normal_' + index + '_' + idx">
                <span>{{idx}}</span>
                <input type="text" v-model="elem.text">
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="question children">
        <div>어린이용 질문</div>
        <div class="questionContainer" v-for="(entry, index) in changedQuestions.children" :key="'children_' + index">
          <div class="questionTitle">
            <span>{{entry.NUMBER}}</span>
            <input type="text" v-model="entry.TITLE" class="titleText">
          </div>
          <div class="questionEntryContainer">
            <ul>
              <li class="questionEntry" v-for="(elem, idx) in entry.CHOICE_ENTRY" :key="'children_' + index + '_' + idx">
                <span>{{idx}}</span>
                <input type="text" v-model="elem.text">
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data () {
    return {
      ID: '',
      PW: '',
      loginSuccess: false,
      changedQuestions: {
        normal: [],
        children: []
      },
      saveStatus: false
    }
  },
  computed: {
    apiServerAddress () {
      return this.$store.state.appConfig.apiServerAddress
    },
    isLogin () {
      return this.loginSuccess
    },
    getID () {
      return this.ID
    },
    getPW () {
      return this.PW
    },
    isSavingData () {
      return this.saveStatus
    }
  },
  methods: {
    saveChangedQuestion () {
      // alert('저장되었습니다.')
      if (this.isSavingData) {
        alert('저장중입니다. 잠시만 기다려주세요.')
        return false
      }
      this.saveStatus = true
      axios.post(this.apiServerAddress + '/question/changeQuestionAll', {
        headers: {'Content-Type': 'application/json'},
        data: { 
           questions: this.changedQuestions
        }
      })
      .then((result) => {
        // console.log(result)
        this.$store.commit('question/setNormal', JSON.parse(JSON.stringify(this.changedQuestions.normal)))
        this.$store.commit('question/setChildren', JSON.parse(JSON.stringify(this.changedQuestions.children)))
        alert('저장 되었습니다.')
        this.saveStatus = false
      })
      .catch((error) => {
        alert('저장되지 않았습니다.')
        // console.log(error)
      })

    },
    loginProcess () {
      // 로그인 아이디는 밑의 if의 조건을 늘려서 적용한다 (임시 JWT를 써서 바꿀것을 요망!)
      if ( this.ID === 'admin' && this.PW === 'Ekdmaollybolly904') {
        this.loginSuccess = true
      } else {
        alert('아이디 혹은 페스워드가 틀립니다. 관리자에게 문의하세요.')
      }
    },
    loadQuestions () {
      axios.get(this.apiServerAddress + '/question/normal')
        .then((response) => {
          this.changedQuestions.normal = response.data
        })
      axios.get(this.apiServerAddress + '/question/children')
        .then((response) => {
          this.changedQuestions.children = response.data
        })
    },
    downloadCSV () {
      window.location.href = this.apiServerAddress + '/survey/downloadResultAll'
    }
  },
  mounted () {
    this.loadQuestions()
  }
}
</script>

<style lang="scss">
#ollybollyApp {
  text-align: center;
  #questionAdminLogin {
    display: inline-block;
    * {
      display: block;
    }
  }
  .buttonContainer {
    position: absolute;
    right: 45%;
  }
  .question {
    display: inline-block;
    vertical-align: top;
    width: 45%;
    .questionContainer {
      margin: 30px 0;
      .questionTitle {
        span {
          display: inline-block;
          padding: 0 15px 0 3px;
          width: 5px;
          height: 20px;
        }
        .titleText {
          width: 90%;
          height: 20px;
        }
      }
      .questionEntryContainer {
        ul {
          list-style: none;
          .questionEntry {
            margin-left: -10px; 
            span {
              display: inline-block;
              padding: 0 15px 0 3px;
              width: 5px;
              height: 20px;
            }
            input {
              width: 80%;
            }
          }
        }
      }
    }
  }
}
</style>
